<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><?php echo e(__('Inventory Report')); ?></span>
                </div>
                <div class="card-body">
                    <!-- Summary Stats -->
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <div class="card bg-primary text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Total Products</h5>
                                    <h2 class="card-text"><?php echo e(count($products)); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-success text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Total Stock</h5>
                                    <h2 class="card-text"><?php echo e($products->sum('stock')); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-warning text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Low Stock Items</h5>
                                    <h2 class="card-text"><?php echo e($products->where('stock', '<', 10)->count()); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-danger text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Out of Stock</h5>
                                    <h2 class="card-text"><?php echo e($products->where('stock', '<=', 0)->count()); ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Filters -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">Filter Inventory</div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('reports.inventory')); ?>" method="GET" class="row g-3">
                                        <div class="col-md-4">
                                            <input type="text" name="search" class="form-control" placeholder="Search products..." value="<?php echo e(request('search')); ?>">
                                        </div>
                                        <div class="col-md-3">
                                            <select name="category" class="form-select">
                                                <option value="">All Categories</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category); ?>" <?php echo e(request('category') == $category ? 'selected' : ''); ?>>
                                                        <?php echo e(ucfirst($category)); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <select name="stock_status" class="form-select">
                                                <option value="">All Stock Levels</option>
                                                <option value="out" <?php echo e(request('stock_status') == 'out' ? 'selected' : ''); ?>>Out of Stock</option>
                                                <option value="low" <?php echo e(request('stock_status') == 'low' ? 'selected' : ''); ?>>Low Stock</option>
                                                <option value="normal" <?php echo e(request('stock_status') == 'normal' ? 'selected' : ''); ?>>Normal Stock</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Inventory Charts -->
                    <div class="row mb-4">
                        <div class="col-md-7">
                            <div class="card">
                                <div class="card-header">Stock Level by Category</div>
                                <div class="card-body">
                                    <canvas id="categoryStockChart" height="280"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="card">
                                <div class="card-header">Stock Status Distribution</div>
                                <div class="card-body">
                                    <canvas id="stockStatusChart" height="280"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Top Products Section -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Top 5 High-Value Products</div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Price</th>
                                                    <th>Stock Value</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $products->sortByDesc(function($product) { return $product->price * $product->stock; })->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($product->name); ?></td>
                                                    <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                                    <td>$<?php echo e(number_format($product->price * $product->stock, 2)); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">Products Needing Restock</div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Current Stock</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $products->where('stock', '<', 10)->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($product->name); ?></td>
                                                    <td><?php echo e($product->stock); ?></td>
                                                    <td>
                                                        <?php if($product->stock <= 0): ?>
                                                            <span class="badge bg-danger">Out of Stock</span>
                                                        <?php elseif($product->stock < 5): ?>
                                                            <span class="badge bg-warning">Critical</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-info">Low</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Inventory Table -->
                    <?php if(isset($products) && count($products)): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead class="table-dark">
                                    <tr>
                                        <th><?php echo e(__('Product Name')); ?></th>
                                        <th><?php echo e(__('Category')); ?></th>
                                        <th><?php echo e(__('Stock')); ?></th>
                                        <th><?php echo e(__('Price')); ?></th>
                                        <th><?php echo e(__('Stock Value')); ?></th>
                                        <th><?php echo e(__('Status')); ?></th>
                                        <th><?php echo e(__('Actions')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php echo e($product->stock < 5 ? 'table-danger' : ($product->stock < 10 ? 'table-warning' : '')); ?>">
                                            <td><?php echo e($product->name); ?></td>
                                            <td>Electronics</td>
                                            <td>
                                                <div class="progress" style="height: 20px;">
                                                    <?php 
                                                        $percentage = min(100, ($product->stock / 30) * 100); 
                                                        $barClass = $product->stock <= 0 ? 'bg-danger' : ($product->stock < 5 ? 'bg-warning' : ($product->stock < 10 ? 'bg-info' : 'bg-success'));
                                                    ?>
                                                    <div class="progress-bar <?php echo e($barClass); ?>" role="progressbar" 
                                                        style="width: <?php echo e($percentage); ?>%;" 
                                                        aria-valuenow="<?php echo e($product->stock); ?>" 
                                                        aria-valuemin="0" 
                                                        aria-valuemax="30"><?php echo e($product->stock); ?></div>
                                                </div>
                                            </td>
                                            <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                            <td>$<?php echo e(number_format($product->price * $product->stock, 2)); ?></td>
                                            <td>
                                                <?php if($product->stock <= 0): ?>
                                                    <span class="badge bg-danger">Out of Stock</span>
                                                <?php elseif($product->stock < 5): ?>
                                                    <span class="badge bg-warning">Critical</span>
                                                <?php elseif($product->stock < 10): ?>
                                                    <span class="badge bg-info">Low</span>
                                                <?php else: ?>
                                                    <span class="badge bg-success">In Stock</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">No inventory data available.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Stock by Category Chart
    const categoryCtx = document.getElementById('categoryStockChart').getContext('2d');
    const categoryData = <?php echo json_encode($categoryData ?? [], 15, 512) ?>;
    
    new Chart(categoryCtx, {
        type: 'bar',
        data: {
            labels: Object.keys(categoryData),
            datasets: [{
                label: 'Total Stock',
                data: Object.values(categoryData).map(item => item.stock),
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }, {
                label: 'Total Value ($)',
                data: Object.values(categoryData).map(item => item.value),
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Stock Quantity'
                    }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Stock Value ($)'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Category'
                    }
                }
            }
        }
    });
    
    // Stock Status Chart
    const statusCtx = document.getElementById('stockStatusChart').getContext('2d');
    const stockStatus = <?php echo json_encode($stockStatus ?? [], 15, 512) ?>;
    
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Out of Stock', 'Critical', 'Low', 'Normal'],
            datasets: [{
                data: [
                    stockStatus.outOfStock ?? 0,
                    stockStatus.critical ?? 0,
                    stockStatus.low ?? 0,
                    stockStatus.normal ?? 0
                ],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',  // red - out of stock
                    'rgba(255, 159, 64, 0.8)',  // orange - critical
                    'rgba(255, 205, 86, 0.8)',  // yellow - low
                    'rgba(75, 192, 192, 0.8)'   // green - normal
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(255, 205, 86, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec_Project-main\resources\views/manager/reports/inventory.blade.php ENDPATH**/ ?>