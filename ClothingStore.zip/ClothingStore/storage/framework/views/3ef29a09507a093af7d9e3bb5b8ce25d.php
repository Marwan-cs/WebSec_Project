<?php use Illuminate\Support\Str; ?>

<?php $__env->startSection('title', $product->name . ' - E-Commerce Store'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('shop')); ?>">Shop</a></li>
                <?php if($product->category): ?>
                <li class="breadcrumb-item"><a href="<?php echo e(route('shop', ['category' => $product->category->slug])); ?>"><?php echo e($product->category->name); ?></a></li>
                <?php endif; ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- Product Images -->
            <div class="col-md-6 mb-4">
                <?php if(isset($product->images) && count($product->images) > 0): ?>
                    <div class="card-body p-0">
                        <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                    <img src="<?php echo e($image->url); ?>" class="d-block w-100" alt="<?php echo e($product->name); ?>">
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if(count($product->images) > 1): ?>
                            <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon"></span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
                                <span class="carousel-control-next-icon"></span>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- Thumbnail Navigation -->
                    <?php if(count($product->images) > 1): ?>
                    <div class="row mt-3">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3">
                            <img src="<?php echo e($image->url); ?>" class="img-thumbnail cursor-pointer" 
                                 onclick="$('#productCarousel').carousel(<?php echo e($index); ?>)" 
                                 alt="<?php echo e($product->name); ?>">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <img src="<?php echo e($product->image_url ?? '/img/shop-details/product-big.png'); ?>" class="img-fluid rounded w-100" alt="<?php echo e($product->name); ?>">
                <?php endif; ?>
            </div>

            <!-- Product Info -->
            <div class="col-md-6">
                <h1 class="mb-3"><?php echo e($product->name); ?></h1>
                
                <!-- Price -->
                <div class="mb-3">
                    <?php if($product->is_sale): ?>
                    <span class="text-decoration-line-through text-muted h4 me-2">$<?php echo e(number_format($product->original_price, 2)); ?></span>
                    <?php endif; ?>
                    <span class="h2 text-primary">$<?php echo e(number_format($product->price, 2)); ?></span>
                    <?php if($product->is_sale): ?>
                    <span class="badge bg-danger ms-2">Sale</span>
                    <?php endif; ?>
                </div>

                <!-- Description -->
                <p class="text-muted mb-4"><?php echo e($product->description); ?></p>

                <!-- Stock Status -->
                <div class="mb-4">
                    <?php if($product->stock > 0): ?>
                    <span class="badge bg-success">In Stock</span>
                    <small class="text-muted ms-2"><?php echo e($product->stock); ?> units available</small>
                    <?php else: ?>
                    <span class="badge bg-danger">Out of Stock</span>
                    <?php endif; ?>
                </div>

                <!-- Add to Cart Form -->
                <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" 
                                   value="1" min="1" max="<?php echo e($product->stock); ?>">
                        </div>
                        <div class="col-md-9 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-lg w-100" 
                                    <?php echo e($product->stock === 0 ? 'disabled' : ''); ?>>
                                <i class="fas fa-shopping-cart me-2"></i>Add to Cart
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Product Meta -->
                <div class="border-top pt-4">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-2">
                                <strong>Category:</strong>
                                <?php if($product->category): ?>
                                    <a href="<?php echo e(route('shop', ['category' => $product->category->slug])); ?>">
                                        <?php echo e($product->category->name); ?>

                                    </a>
                                <?php else: ?>
                                    <span>No Category</span>
                                <?php endif; ?>
                            </p>
                            <p class="mb-2">
                                <strong>Brand:</strong>
                                <?php if($product->brand): ?>
                                    <a href="<?php echo e(route('shop', ['brand' => $product->brand->slug])); ?>">
                                        <?php echo e($product->brand->name); ?>

                                    </a>
                                <?php else: ?>
                                    <span>No Brand</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-2">
                                <strong>SKU:</strong> <?php echo e($product->sku); ?>

                            </p>
                            <p class="mb-2">
                                <strong>Weight:</strong> <?php echo e($product->weight); ?> kg
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Social Share -->
                <div class="border-top pt-4">
                    <h5>Share this product:</h5>
                    <div class="d-flex gap-2">
                        <a href="#" class="btn btn-outline-primary" onclick="shareOnFacebook()">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="btn btn-outline-info" onclick="shareOnTwitter()">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="btn btn-outline-danger" onclick="shareOnPinterest()">
                            <i class="fab fa-pinterest-p"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Product Tabs -->
        <div class="row mt-5">
            <div class="col-12">
                <ul class="nav nav-tabs" id="productTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="description-tab" data-bs-toggle="tab" href="#description">
                            Description
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="specifications-tab" data-bs-toggle="tab" href="#specifications">
                            Specifications
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="reviews-tab" data-bs-toggle="tab" href="#reviews">
                            Reviews
                        </a>
                    </li>
                </ul>
                <div class="tab-content p-4 border border-top-0 rounded-bottom">
                    <div class="tab-pane fade show active" id="description">
                        <?php echo $product->long_description; ?>

                    </div>
                    <div class="tab-pane fade" id="specifications">
                        <table class="table">
                            <tbody>
                                <?php if(!empty($product->specifications) && is_iterable($product->specifications)): ?>
                                    <?php $__currentLoopData = $product->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($key); ?></th>
                                        <td><?php echo e($value); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="2">No specifications available.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="reviews">
                        <?php if(!empty($product->reviews) && is_countable($product->reviews) && $product->reviews->count() > 0): ?>
                            <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <h6 class="mb-0"><?php echo e($review->user->name); ?></h6>
                                        <div class="text-warning">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fas fa-star<?php echo e($i <= $review->rating ? '' : '-o'); ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <small class="text-muted"><?php echo e($review->created_at->diffForHumans()); ?></small>
                                </div>
                                <p class="mb-0"><?php echo e($review->comment); ?></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-muted">No reviews yet.</p>
                        <?php endif; ?>

                        <?php if(auth()->guard()->check()): ?>
                        <div class="mt-4">
                            <h5>Write a Review</h5>
                            <form action="<?php echo e(route('reviews.store', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label class="form-label">Rating</label>
                                    <div class="rating">
                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                        <input type="radio" name="rating" value="<?php echo e($i); ?>" id="star<?php echo e($i); ?>">
                                        <label for="star<?php echo e($i); ?>"><i class="fas fa-star"></i></label>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="comment" class="form-label">Your Review</label>
                                    <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit Review</button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <?php if($relatedProducts->count() > 0): ?>
        <div class="row mt-5">
            <div class="col-12">
                <h3 class="mb-4">Related Products</h3>
                <div class="row g-4">
                    <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="card h-100">
                            <img src="<?php echo e($relatedProduct->image_url ?? '/img/product/product-1.jpg'); ?>" class="card-img-top" alt="<?php echo e($relatedProduct->name); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($relatedProduct->name); ?></h5>
                                <p class="card-text text-muted"><?php echo e(Str::limit($relatedProduct->description, 100)); ?></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="h5 mb-0">$<?php echo e(number_format($relatedProduct->price, 2)); ?></span>
                                    <a href="<?php echo e(url('/shop-details/' . $relatedProduct->id)); ?>" class="btn btn-primary">View</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .rating {
        display: flex;
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    .rating input {
        display: none;
    }
    .rating label {
        cursor: pointer;
        color: #ddd;
        font-size: 1.5rem;
        padding: 0 0.1em;
    }
    .rating input:checked ~ label,
    .rating label:hover,
    .rating label:hover ~ label {
        color: #ffd700;
    }
    .cursor-pointer {
        cursor: pointer;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function shareOnFacebook() {
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`);
    }

    function shareOnTwitter() {
        window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent('<?php echo e($product->name); ?>')}`);
    }

    function shareOnPinterest() {
        window.open(`https://pinterest.com/pin/create/button/?url=${encodeURIComponent(window.location.href)}&media=${encodeURIComponent('<?php echo e($product->image_url); ?>')}&description=${encodeURIComponent('<?php echo e($product->name); ?>')}`);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\WebProject\ClothingStore\resources\views/webfront/shop-details.blade.php ENDPATH**/ ?>