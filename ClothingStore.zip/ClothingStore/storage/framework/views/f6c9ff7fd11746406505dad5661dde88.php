<?php $__env->startSection('title', 'Shopping Cart - E-Commerce Store'); ?>

<?php use App\Models\Cart; ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <h1 class="mb-4">Shopping Cart</h1>

        <?php if(Cart::count() > 0): ?>
        <div class="row">
            <!-- Cart Items -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo e($item['image'] ?? '/img/product/product-1.jpg'); ?>" alt="<?php echo e($item['name']); ?>" 
                                                     class="img-thumbnail me-3" style="width: 80px;">
                                                <div>
                                                    <h6 class="mb-0"><?php echo e($item['name']); ?></h6>
                                                    <small class="text-muted">
                                                        <?php if(isset($item['size'])): ?>
                                                            Size: <?php echo e($item['size']); ?>

                                                        <?php endif; ?>
                                                        <?php if(isset($item['color'])): ?>
                                                            Color: <?php echo e($item['color']); ?>

                                                        <?php endif; ?>
                                                    </small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$<?php echo e(number_format($item['price'], 2)); ?></td>
                                        <td>
                                            <div class="input-group" style="width: 120px;">
                                                <button type="button" class="btn btn-outline-secondary btn-sm" 
                                                        onclick="updateQuantity(<?php echo e($id); ?>, 'decrease')">-</button>
                                                <input type="number" class="form-control form-control-sm text-center" 
                                                       value="<?php echo e($item['quantity']); ?>" min="1" max="<?php echo e($item['stock'] ?? 99); ?>"
                                                       onchange="updateQuantity(<?php echo e($id); ?>, 'set', this.value)">
                                                <button type="button" class="btn btn-outline-secondary btn-sm" 
                                                        onclick="updateQuantity(<?php echo e($id); ?>, 'increase')">+</button>
                                            </div>
                                        </td>
                                        <td>$<?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-link text-danger" 
                                                    onclick="removeItem('<?php echo e($id); ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Cart Actions -->
                <div class="d-flex justify-content-between mt-4">
                    <a href="<?php echo e(route('shop')); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                    </a>
                    <button type="button" class="btn btn-outline-danger" onclick="clearCart()">
                        <i class="fas fa-trash me-2"></i>Clear Cart
                    </button>
                </div>
            </div>

            <!-- Order Summary -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Order Summary</h5>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal</span>
                            <span>$<?php echo e(number_format(Cart::total(), 2)); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Tax</span>
                            <span>$0.00</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Shipping</span>
                            <span>Free</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <strong>Total</strong>
                            <strong class="text-primary">$<?php echo e(number_format(Cart::total(), 2)); ?></strong>
                        </div>
                        <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-primary w-100">
                            Proceed to Checkout
                        </a>
                    </div>
                </div>

                <!-- Promo Code -->
                <div class="card mt-4">
                    <div class="card-body">
                        <h5 class="card-title">Promo Code</h5>
                        <form id="promoForm" class="d-flex gap-2">
                            <input type="text" class="form-control" placeholder="Enter promo code">
                            <button type="submit" class="btn btn-outline-primary">Apply</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
            <h3>Your cart is empty</h3>
            <p class="text-muted">Looks like you haven't added any items to your cart yet.</p>
            <a href="<?php echo e(route('shop')); ?>" class="btn btn-primary mt-3">
                Start Shopping
            </a>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function updateQuantity(rowId, action, value = null) {
        let currentQty = parseInt(document.querySelector(`input[value="${value}"]`).value);
        let newQty = currentQty;

        if (action === 'increase') {
            newQty = currentQty + 1;
        } else if (action === 'decrease') {
            newQty = currentQty - 1;
        } else if (action === 'set') {
            newQty = parseInt(value);
        }

        if (newQty < 1) return;

        fetch(`/cart/update/${rowId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ quantity: newQty })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error updating cart');
        });
    }

    function removeItem(rowId) {
        if (!confirm('Are you sure you want to remove this item?')) return;

        fetch(`/cart/remove/${rowId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error removing item');
        });
    }

    function clearCart() {
        if (!confirm('Are you sure you want to clear your cart?')) return;

        fetch('/cart/clear', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error clearing cart');
        });
    }

    // Promo code form submission
    document.getElementById('promoForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const code = this.querySelector('input').value;

        fetch('/cart/apply-promo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({ code })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            } else {
                alert(data.message || 'Invalid promo code');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error applying promo code');
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec_Project-main\resources\views/cart/index.blade.php ENDPATH**/ ?>