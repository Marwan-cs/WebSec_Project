<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">User Profile</h5>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary btn-sm">Edit Profile</a>
                </div>

                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Name:</div>
                        <div class="col-md-8"><?php echo e($user->name); ?></div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Email:</div>
                        <div class="col-md-8"><?php echo e($user->email); ?></div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Roles:</div>
                        <div class="col-md-8">
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-primary me-1"><?php echo e($role->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Created At:</div>
                        <div class="col-md-8"><?php echo e($user->created_at->format('F j, Y g:i a')); ?></div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Last Updated:</div>
                        <div class="col-md-8"><?php echo e($user->updated_at->format('F j, Y g:i a')); ?></div>
                    </div>

                    <?php if($user->email_verified_at): ?>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Email Verified:</div>
                            <div class="col-md-8">
                                <span class="badge bg-success">Yes</span>
                                (<?php echo e($user->email_verified_at->format('F j, Y g:i a')); ?>)
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Email Verified:</div>
                            <div class="col-md-8">
                                <span class="badge bg-warning">No</span>
                                <a href="<?php echo e(route('verification.send')); ?>" class="btn btn-link btn-sm">Resend Verification Email</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\CLICK LAPTOPS\Desktop\ClothingStore\resources\views/profile/show.blade.php ENDPATH**/ ?>