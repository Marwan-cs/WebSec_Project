<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo e(__('Products')); ?></h5>
                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">
                        <?php echo e(__('Add New Product')); ?>

                    </a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Image')); ?></th>
                                    <th><?php echo e(__('Name')); ?></th>
                                    <th><?php echo e(__('Category')); ?></th>
                                    <th><?php echo e(__('Price')); ?></th>
                                    <th><?php echo e(__('Stock')); ?></th>
                                    <th><?php echo e(__('Actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <?php if($product->image): ?>
                                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" style="max-width: 50px;">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="No Image" style="max-width: 50px;">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e(ucfirst($product->category)); ?></td>
                                        <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                        <td><?php echo e($product->stock); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-info btn-sm">
                                                    <?php echo e(__('View')); ?>

                                                </a>
                                                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary btn-sm">
                                                    <?php echo e(__('Edit')); ?>

                                                </a>
                                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('Are you sure you want to delete this product?')); ?>')">
                                                        <?php echo e(__('Delete')); ?>

                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center"><?php echo e(__('No products found.')); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if($products->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($products->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec_Project-main\resources\views/products/index.blade.php ENDPATH**/ ?>